function navigateTo(page) {
  if (page === "register") {
    alert("Navigating to Register Page");
    // Replace the alert with actual navigation code
    // Example: window.location.href = 'register.html';
  } else if (page === "login") {
    alert("Navigating to Login Page");
    // Replace the alert with actual navigation code
    // Example: window.location.href = 'login.html';
  }
}
